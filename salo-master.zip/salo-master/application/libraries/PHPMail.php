<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class PHPMail {
public function PHPMail()
{
    require_once('PHPMailer/PHPMailerAutoload.php');
}
}
?>