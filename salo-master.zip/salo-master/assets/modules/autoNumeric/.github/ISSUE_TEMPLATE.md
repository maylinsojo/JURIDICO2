### Expected behavior
<Please describe the expected behavior here>

### Actual behavior
<Please describe what you actually got instead here>

### Steps to reproduce the problem
1. Using autoNumeric `<vX.X.X>` and the browser `<Chrome|Firefox>` version `<YY>` on `<Linux>`,
2. I used the options <{ zzzz: tttt }>, and 
3. Initialized my AutoNumeric object with the call `<new AutoNumeric(domElement, { options })>`,
4. <Then my computer exploded, for real.>

### Link to live example (ie. [Codepen](http://codepen.io/pen/))
<Providing a live example of your problem that reproduce what you are experiencing usually means we'll be able to fix your issue *much more quickly* than if you don't.>
<Also, when creating an extract of your problem, you are likely to find the cause of it, and fix it yourself, :tada: ;)>

Thanks for reporting a bug or giving us great ideas with your feature request!
